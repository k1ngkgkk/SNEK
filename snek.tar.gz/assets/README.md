# Snek

A mouse-controlled bob omb like snake game built with Python and Pygame.

## Gameplay
* Move the mouse to guide the snake.
* Eat gray rats to grow and score points.
* Eat yellow wildcards to invert your mouse controls.
* Avoid hitting the rats hitting your body from the side.
* Press any key to restart after dying.

## Setup
1. Install Pygame:
   pip install pygame

2. Run the game:
   python snek.py

## Demo
https://youtu.be/czb68Nx76AI?si=8a2WenA2UStx902z

## AI Usage
* Mirroring the text
* The blood spatter

## Credits
@Alba_Mac on PixaBay for the background music
@FreeSoundCommunity on PixaBay for the death sound
